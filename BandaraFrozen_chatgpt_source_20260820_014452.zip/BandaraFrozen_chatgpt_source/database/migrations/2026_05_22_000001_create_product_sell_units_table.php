<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('product_sell_units', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('sku', 120)->nullable()->index();
            $table->string('barcode', 120)->nullable()->index();
            $table->string('unit_type', 40)->default('pack')->index();
            $table->string('pricing_unit', 40)->default('pack');
            $table->decimal('pieces_per_unit', 12, 3)->nullable();
            $table->decimal('weight_per_unit_kg', 12, 3)->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_retail_visible')->default(true)->index();
            $table->boolean('is_b2b_visible')->default(true)->index();
            $table->boolean('is_active')->default(true)->index();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['product_id', 'is_active', 'sort_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_sell_units');
    }
};
