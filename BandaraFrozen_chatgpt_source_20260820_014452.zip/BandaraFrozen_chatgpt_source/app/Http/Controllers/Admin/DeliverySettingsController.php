<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DeliveryChargeRule;
use App\Models\DeliveryDistanceRule;
use App\Models\DeliveryZone;
use App\Models\DeliveryZonePincode;
use App\Models\HandlingChargeRule;
use App\Models\HsnCode;
use App\Services\DeliveryTaxSettingsService;
use Illuminate\Http\Request;

class DeliverySettingsController extends Controller
{
    public function index(DeliveryTaxSettingsService $taxSettings)
    {
        return view('admin.delivery.index', [
            'zones' => DeliveryZone::query()
                ->with(['pincodes' => fn ($query) => $query->orderBy('pincode'), 'deliveryChargeRules' => fn ($query) => $query->orderBy('customer_type')->orderBy('min_order_value')])
                ->orderBy('sort_order')
                ->orderBy('id')
                ->get(),
            'distanceRules' => DeliveryDistanceRule::query()
                ->orderBy('customer_type')
                ->orderBy('min_distance_km')
                ->orderBy('min_order_value')
                ->get(),
            'handlingRules' => HandlingChargeRule::query()
                ->orderBy('customer_type')
                ->orderBy('temperature_mode')
                ->orderBy('min_order_value')
                ->get(),
            'hsnCodes' => HsnCode::query()
                ->where('is_active', true)
                ->orderBy('code')
                ->get(),
            'deliveryTaxSettings' => $taxSettings->current(),
        ]);
    }

    public function updateTaxSettings(Request $request, DeliveryTaxSettingsService $taxSettings)
    {
        $data = $request->validate([
            'delivery_hsn_code_id' => ['nullable', 'integer', 'exists:hsn_codes,id'],
            'handling_hsn_code_id' => ['nullable', 'integer', 'exists:hsn_codes,id'],
            'sync_delivery_rules' => ['nullable', 'boolean'],
            'sync_handling_rules' => ['nullable', 'boolean'],
        ]);

        $updated = $taxSettings->update(
            deliveryHsnCodeId: $data['delivery_hsn_code_id'] ?? null,
            handlingHsnCodeId: $data['handling_hsn_code_id'] ?? null,
            syncDeliveryRules: $request->boolean('sync_delivery_rules'),
            syncHandlingRules: $request->boolean('sync_handling_rules'),
        );

        $message = 'Delivery HSN/SAC settings updated.';

        if (($updated['delivery_zone_rules'] + $updated['delivery_distance_rules'] + $updated['handling_rules']) > 0) {
            $message .= sprintf(
                ' Synced GST rate on %d zone rules, %d distance rules and %d cold-chain rules.',
                $updated['delivery_zone_rules'],
                $updated['delivery_distance_rules'],
                $updated['handling_rules'],
            );
        }

        return back()->with('success', $message);
    }

    public function storeZone(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'code' => ['required', 'string', 'max:80', 'unique:delivery_zones,code'],
            'description' => ['nullable', 'string', 'max:5000'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $data['code'] = strtoupper(trim($data['code']));
        $data['is_active'] = $request->boolean('is_active', true);
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        DeliveryZone::create($data);

        return back()->with('success', 'Delivery zone created.');
    }

    public function updateZone(Request $request, DeliveryZone $zone)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'code' => ['required', 'string', 'max:80', 'unique:delivery_zones,code,' . $zone->id],
            'description' => ['nullable', 'string', 'max:5000'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $data['code'] = strtoupper(trim($data['code']));
        $data['is_active'] = $request->boolean('is_active');
        $data['sort_order'] = (int) ($data['sort_order'] ?? 0);

        $zone->update($data);

        return back()->with('success', 'Delivery zone updated.');
    }

    public function storePincode(Request $request, DeliveryZone $zone)
    {
        $request->merge([
            'pincode' => preg_replace('/\D+/', '', (string) $request->input('pincode')),
        ]);

        $data = $request->validate([
            'pincode' => ['required', 'string', 'max:10', 'unique:delivery_zone_pincodes,pincode'],
            'city' => ['nullable', 'string', 'max:120'],
            'area_name' => ['nullable', 'string', 'max:160'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $data['is_active'] = $request->boolean('is_active', true);

        $zone->pincodes()->create($data);

        return back()->with('success', 'Pincode added to delivery zone.');
    }

    public function destroyPincode(DeliveryZonePincode $pincode)
    {
        $pincode->delete();

        return back()->with('success', 'Pincode removed.');
    }

    public function storeDeliveryRule(Request $request, DeliveryZone $zone)
    {
        $data = $request->validate([
            'customer_type' => ['required', 'in:all,guest,b2c,b2b'],
            'min_order_value' => ['nullable', 'numeric', 'min:0'],
            'delivery_fee' => ['nullable', 'numeric', 'min:0'],
            'free_delivery_above' => ['nullable', 'numeric', 'min:0'],
            'tax_rate' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
        ]);

        $data = $this->normalizeMoneyRule($request, $data, 'delivery_fee', 'free_delivery_above');
        $zone->deliveryChargeRules()->create($data);

        return back()->with('success', 'Delivery fee rule added.');
    }

    public function updateDeliveryRule(Request $request, DeliveryChargeRule $rule)
    {
        $data = $request->validate([
            'customer_type' => ['required', 'in:all,guest,b2c,b2b'],
            'min_order_value' => ['nullable', 'numeric', 'min:0'],
            'delivery_fee' => ['nullable', 'numeric', 'min:0'],
            'free_delivery_above' => ['nullable', 'numeric', 'min:0'],
            'tax_rate' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
        ]);

        $data = $this->normalizeMoneyRule($request, $data, 'delivery_fee', 'free_delivery_above');
        $rule->update($data);

        return back()->with('success', 'Delivery fee rule updated.');
    }

    public function destroyDeliveryRule(DeliveryChargeRule $rule)
    {
        $rule->delete();

        return back()->with('success', 'Delivery fee rule removed.');
    }


    public function storeDistanceRule(Request $request)
    {
        $data = $request->validate([
            'customer_type' => ['required', 'in:all,guest,b2c,b2b'],
            'min_order_value' => ['nullable', 'numeric', 'min:0'],
            'min_distance_km' => ['nullable', 'numeric', 'min:0'],
            'max_distance_km' => ['nullable', 'numeric', 'min:0', 'gte:min_distance_km'],
            'delivery_fee' => ['nullable', 'numeric', 'min:0'],
            'included_distance_km' => ['nullable', 'numeric', 'min:0'],
            'per_km_fee' => ['nullable', 'numeric', 'min:0'],
            'free_delivery_above' => ['nullable', 'numeric', 'min:0'],
            'tax_rate' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
        ]);

        $data = $this->normalizeDistanceRule($request, $data);
        DeliveryDistanceRule::create($data);

        return back()->with('success', 'Distance-based delivery fee rule added.');
    }

    public function updateDistanceRule(Request $request, DeliveryDistanceRule $rule)
    {
        $data = $request->validate([
            'customer_type' => ['required', 'in:all,guest,b2c,b2b'],
            'min_order_value' => ['nullable', 'numeric', 'min:0'],
            'min_distance_km' => ['nullable', 'numeric', 'min:0'],
            'max_distance_km' => ['nullable', 'numeric', 'min:0', 'gte:min_distance_km'],
            'delivery_fee' => ['nullable', 'numeric', 'min:0'],
            'included_distance_km' => ['nullable', 'numeric', 'min:0'],
            'per_km_fee' => ['nullable', 'numeric', 'min:0'],
            'free_delivery_above' => ['nullable', 'numeric', 'min:0'],
            'tax_rate' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
        ]);

        $data = $this->normalizeDistanceRule($request, $data);
        $rule->update($data);

        return back()->with('success', 'Distance-based delivery fee rule updated.');
    }

    public function destroyDistanceRule(DeliveryDistanceRule $rule)
    {
        $rule->delete();

        return back()->with('success', 'Distance-based delivery fee rule removed.');
    }

    public function storeHandlingRule(Request $request)
    {
        $data = $request->validate([
            'customer_type' => ['required', 'in:all,guest,b2c,b2b'],
            'temperature_mode' => ['required', 'in:all,frozen,chilled,ambient'],
            'min_order_value' => ['nullable', 'numeric', 'min:0'],
            'handling_fee' => ['nullable', 'numeric', 'min:0'],
            'free_handling_above' => ['nullable', 'numeric', 'min:0'],
            'tax_rate' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
        ]);

        $data = $this->normalizeMoneyRule($request, $data, 'handling_fee', 'free_handling_above');
        HandlingChargeRule::create($data);

        return back()->with('success', 'Handling fee rule added.');
    }

    public function updateHandlingRule(Request $request, HandlingChargeRule $rule)
    {
        $data = $request->validate([
            'customer_type' => ['required', 'in:all,guest,b2c,b2b'],
            'temperature_mode' => ['required', 'in:all,frozen,chilled,ambient'],
            'min_order_value' => ['nullable', 'numeric', 'min:0'],
            'handling_fee' => ['nullable', 'numeric', 'min:0'],
            'free_handling_above' => ['nullable', 'numeric', 'min:0'],
            'tax_rate' => ['nullable', 'numeric', 'min:0', 'max:100'],
            'is_active' => ['nullable', 'boolean'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
        ]);

        $data = $this->normalizeMoneyRule($request, $data, 'handling_fee', 'free_handling_above');
        $rule->update($data);

        return back()->with('success', 'Handling fee rule updated.');
    }

    public function destroyHandlingRule(HandlingChargeRule $rule)
    {
        $rule->delete();

        return back()->with('success', 'Handling fee rule removed.');
    }


    private function normalizeDistanceRule(Request $request, array $data): array
    {
        $data['min_order_value'] = round((float) ($data['min_order_value'] ?? 0), 2);
        $data['min_distance_km'] = round((float) ($data['min_distance_km'] ?? 0), 2);
        $data['max_distance_km'] = $request->filled('max_distance_km') ? round((float) $data['max_distance_km'], 2) : null;
        $data['delivery_fee'] = round((float) ($data['delivery_fee'] ?? 0), 2);

        // Keep these dynamic-fee fields tied to the raw request values. The inline
        // distance-rule editor is rendered as a table, and some browsers are strict
        // about nested form/table markup. Using the request directly, together with
        // explicit form attributes in the Blade, ensures "Base covers km" is saved
        // reliably from both create and edit rows.
        $includedDistance = $request->input('included_distance_km');
        $data['included_distance_km'] = $includedDistance === null || $includedDistance === ''
            ? 0.0
            : round((float) $includedDistance, 2);

        $perKmFee = $request->input('per_km_fee');
        $data['per_km_fee'] = $perKmFee === null || $perKmFee === ''
            ? null
            : round((float) $perKmFee, 2);

        $data['free_delivery_above'] = $request->filled('free_delivery_above') ? round((float) $data['free_delivery_above'], 2) : null;
        $data['tax_rate'] = app(DeliveryTaxSettingsService::class)->deliveryTaxRate(
            isset($data['tax_rate']) ? (float) $data['tax_rate'] : null
        );
        $data['is_active'] = $request->boolean('is_active');

        return $data;
    }

    private function normalizeMoneyRule(Request $request, array $data, string $feeField, string $freeAboveField): array
    {
        $data['min_order_value'] = round((float) ($data['min_order_value'] ?? 0), 2);
        $data[$feeField] = round((float) ($data[$feeField] ?? 0), 2);
        $data[$freeAboveField] = $request->filled($freeAboveField) ? round((float) $data[$freeAboveField], 2) : null;
        $isHandlingRule = $feeField === 'handling_fee';
        $data['tax_rate'] = $isHandlingRule
            ? app(DeliveryTaxSettingsService::class)->handlingTaxRate(isset($data['tax_rate']) ? (float) $data['tax_rate'] : null)
            : app(DeliveryTaxSettingsService::class)->deliveryTaxRate(isset($data['tax_rate']) ? (float) $data['tax_rate'] : null);
        $data['is_active'] = $request->boolean('is_active');

        return $data;
    }
}
